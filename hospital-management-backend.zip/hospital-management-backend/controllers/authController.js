const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const RefreshToken = require('../models/RefreshToken');
const asyncHandler = require('../utils/asyncHandler');
const {createAccessToken,createRefreshToken} = require('../utils/tokens');
const {logAction} = require('../utils/audit');
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
exports.register = asyncHandler(async (req,res) => {
  const {name,email,password} = req.body;
  if (!name || !email || !password || password.length < 8) return res.status(400).json({message:'Name, valid email and password (8+ chars) are required'});
  const user = await User.create({name,email,password,role:'patient'}); // Public signup can NEVER select admin.
  res.status(201).json({message:'Patient registered', user:{id:user._id,name:user.name,email:user.email,role:user.role}});
});
exports.login = asyncHandler(async (req,res) => {
  const {email,password} = req.body;
  const user = await User.findOne({email}).select('+password +refreshTokenHash');
  if (!user || user.isBlocked) return res.status(401).json({message:'Invalid credentials or blocked account'});
  if (user.lockUntil && user.lockUntil > Date.now()) return res.status(423).json({message:'Account temporarily locked. Try again later.'});
  if (!(await user.comparePassword(password || ''))) {
    user.failedLoginAttempts += 1;
    if (user.failedLoginAttempts >= 5) user.lockUntil = new Date(Date.now()+15*60*1000);
    await user.save(); return res.status(401).json({message:'Invalid credentials'});
  }
  user.failedLoginAttempts = 0; user.lockUntil = null;
  const accessToken = createAccessToken(user), refreshToken = createRefreshToken(user);
  user.refreshTokenHash = hash(refreshToken); await user.save();
  await RefreshToken.create({user:user._id,tokenHash:hash(refreshToken),expiresAt:new Date(Date.now()+7*86400000)});
  await logAction(req,'login','User',user._id);
  res.json({accessToken,refreshToken,user:{id:user._id,name:user.name,email:user.email,role:user.role}});
});
exports.refresh = asyncHandler(async (req,res) => {
  const {refreshToken} = req.body; if (!refreshToken) return res.status(401).json({message:'Refresh token required'});
  let payload; try { payload=jwt.verify(refreshToken,process.env.JWT_REFRESH_SECRET); } catch { return res.status(401).json({message:'Invalid refresh token'}); }
  const tokenDoc = await RefreshToken.findOne({user:payload.sub,tokenHash:hash(refreshToken)});
  const user = await User.findById(payload.sub).select('+refreshTokenHash');
  if (!tokenDoc || !user || user.isBlocked || user.refreshTokenHash !== hash(refreshToken)) return res.status(401).json({message:'Refresh token revoked'});
  await RefreshToken.deleteMany({user:user._id});
  const nextRefresh = createRefreshToken(user); user.refreshTokenHash=hash(nextRefresh); await user.save();
  await RefreshToken.create({user:user._id,tokenHash:hash(nextRefresh),expiresAt:new Date(Date.now()+7*86400000)});
  res.json({accessToken:createAccessToken(user),refreshToken:nextRefresh});
});
exports.logout = asyncHandler(async (req,res) => {
  const {refreshToken} = req.body;
  if (refreshToken) { await RefreshToken.deleteOne({user:req.user._id,tokenHash:hash(refreshToken)}); const user=await User.findById(req.user._id).select('+refreshTokenHash'); user.refreshTokenHash=null; await user.save(); }
  await logAction(req,'logout','User',req.user._id); res.json({message:'Logged out; refresh token invalidated'});
});
exports.me = (req,res) => res.json({user:{id:req.user._id,name:req.user.name,email:req.user.email,role:req.user.role}});
exports.forgotPassword = asyncHandler(async (req,res) => {
  const user=await User.findOne({email:req.body.email}).select('+resetTokenHash +resetTokenExpires');
  // In production, email this token. Returning it is for local assignment testing only; remove before deployment.
  if (!user) return res.json({message:'If the account exists, reset instructions have been generated'});
  const token=crypto.randomBytes(32).toString('hex'); user.resetTokenHash=hash(token); user.resetTokenExpires=new Date(Date.now()+15*60*1000); await user.save();
  res.json({message:'Local demo reset token (send by email in production)',resetToken:token});
});
exports.resetPassword = asyncHandler(async (req,res) => {
  const user=await User.findOne({resetTokenHash:hash(req.body.token || ''),resetTokenExpires:{$gt:Date.now()}}).select('+resetTokenHash +resetTokenExpires');
  if (!user || !req.body.password || req.body.password.length<8) return res.status(400).json({message:'Invalid/expired token or weak password'});
  user.password=req.body.password; user.resetTokenHash=null; user.resetTokenExpires=null; user.refreshTokenHash=null; await user.save(); await RefreshToken.deleteMany({user:user._id}); res.json({message:'Password reset successful'});
});
