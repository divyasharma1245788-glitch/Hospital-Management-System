const router=require('express').Router();const {body}=require('express-validator');const validate=require('../middlewares/validate');const auth=require('../middlewares/auth');const c=require('../controllers/authController');
router.post('/register',[body('name').trim().notEmpty(),body('email').isEmail(),body('password').isLength({min:8})],validate,c.register);
router.post('/login',[body('email').isEmail(),body('password').notEmpty()],validate,c.login);
router.post('/refresh',c.refresh);router.post('/logout',auth.authenticate,c.logout);router.get('/me',auth.authenticate,c.me);
router.post('/forgot-password',body('email').isEmail(),validate,c.forgotPassword);router.post('/reset-password',body('token').notEmpty(),body('password').isLength({min:8}),validate,c.resetPassword);
module.exports=router;
