const router=require('express').Router();const auth=require('../middlewares/auth');const c=require('../controllers/adminController');const hospital=require('../controllers/hospitalController');const {hasPermission}=require('../middlewares/permissions');
router.use(auth.authenticate,auth.authorize('admin'));
router.get('/users',hasPermission('user:read'),c.listUsers);router.patch('/users/:id/role',hasPermission('user:role'),c.changeRole);router.patch('/users/:id/block',hasPermission('user:block'),c.setBlocked);router.get('/audit-logs',hospital.auditLogs);
module.exports=router;
