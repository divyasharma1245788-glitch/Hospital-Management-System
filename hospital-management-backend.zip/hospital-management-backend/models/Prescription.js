const mongoose = require('mongoose');
module.exports = mongoose.model('Prescription', new mongoose.Schema({
  appointment: {type:mongoose.Schema.Types.ObjectId, ref:'Appointment', required:true, unique:true},
  patient: {type:mongoose.Schema.Types.ObjectId, ref:'User', required:true},
  doctor: {type:mongoose.Schema.Types.ObjectId, ref:'User', required:true},
  diagnosis: {type:String, required:true}, medicines: [{name:String, dosage:String, duration:String}], notes:String
}, {timestamps:true}));
