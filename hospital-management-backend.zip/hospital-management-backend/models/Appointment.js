const mongoose = require('mongoose');
const schema = new mongoose.Schema({
  patient: {type:mongoose.Schema.Types.ObjectId, ref:'User', required:true},
  doctor: {type:mongoose.Schema.Types.ObjectId, ref:'User', required:true},
  department: {type:mongoose.Schema.Types.ObjectId, ref:'Department'},
  scheduledAt: {type:Date, required:true},
  reason: {type:String, trim:true},
  status: {type:String, enum:['booked','completed','cancelled'], default:'booked'}
}, {timestamps:true});
schema.index({doctor:1, scheduledAt:1});
module.exports = mongoose.model('Appointment', schema);
