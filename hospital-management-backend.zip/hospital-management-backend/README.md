# Hospital Management System — Backend

Node.js + Express + MongoDB + Mongoose API for the assignment's Project 1. It implements authentication, authorization, role-based access control, ownership checks, admin APIs and the bonus features shown in the supplied assignment screenshots.

## 1. Requirements
- Node.js 18+
- MongoDB running locally or a MongoDB Atlas connection string
- Postman

## 2. Setup
```bash
npm install
cp .env.example .env
```
Edit `.env`: set `MONGO_URI` and replace all JWT secrets and the admin password with private random values. Never commit `.env`.

Create the first admin:
```bash
npm run seed:admin
```
Start the API:
```bash
npm run dev
```
Health check: `GET http://localhost:5000/api/health`

## 3. Roles
- **Admin:** manage departments and users, change roles, block/unblock accounts, view audit logs and all records.
- **Doctor:** view assigned appointments and write prescriptions only for appointments assigned to them.
- **Receptionist:** register patients and manage appointment bookings.
- **Patient:** book appointments and view only their own appointments and prescriptions.

Public registration always creates a `patient`; it ignores any submitted `role` field.

## 4. API routes
All request bodies are JSON. After login, send `Authorization: Bearer <accessToken>` for protected routes.

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Register patient |
| POST | `/api/auth/login` | Public, rate-limited | Login; returns access + refresh tokens |
| POST | `/api/auth/refresh` | Refresh token | Rotate tokens |
| POST | `/api/auth/logout` | Authenticated | Revoke refresh token |
| GET | `/api/auth/me` | Authenticated | Current user |
| POST | `/api/auth/forgot-password` | Public | Generate expiring reset token |
| POST | `/api/auth/reset-password` | Reset token | Set new password |
| GET | `/api/departments` | Public | List departments |
| POST | `/api/departments` | Admin | Create department |
| POST | `/api/patients` | Admin/Receptionist | Register patient |
| POST | `/api/appointments` | All roles | Book appointment |
| GET | `/api/appointments` | All roles | List permitted appointments |
| PATCH | `/api/appointments/:id` | Authenticated roles | Update permitted appointment |
| DELETE | `/api/appointments/:id` | Admin/Patient | Cancel own appointment or admin cancel |
| POST | `/api/prescriptions` | Admin/Doctor | Create prescription |
| GET | `/api/prescriptions` | Admin/Doctor/Patient | List permitted prescriptions |
| GET | `/api/admin/users` | Admin | List/search/filter users; pagination |
| PATCH | `/api/admin/users/:id/role` | Admin | Change user role |
| PATCH | `/api/admin/users/:id/block` | Admin | Block/unblock user; body `{ "blocked": true }` |
| GET | `/api/admin/audit-logs` | Admin | Audit trail with pagination |

### Useful request examples
Register: `POST /api/auth/register`
```json
{"name":"Aarav Sharma","email":"aarav@example.com","password":"StrongPass123!"}
```
Login: `POST /api/auth/login`
```json
{"email":"aarav@example.com","password":"StrongPass123!"}
```
Book appointment as patient:
```json
{"doctor":"DOCTOR_OBJECT_ID","scheduledAt":"2026-11-05T10:30:00.000Z","reason":"General check-up"}
```
Receptionist booking requires a `patient` ID in addition to `doctor` and `scheduledAt`.
Create prescription as assigned doctor:
```json
{"appointment":"APPOINTMENT_OBJECT_ID","diagnosis":"Seasonal allergy","medicines":[{"name":"Example medicine","dosage":"As prescribed","duration":"5 days"}],"notes":"Follow-up if symptoms continue"}
```

## 5. Security and assignment checklist
- Passwords are hashed with bcrypt; plaintext passwords are never returned.
- JWT access token is short-lived (15 minutes by default); refresh token lasts 7 days and is stored as a SHA-256 hash in the database.
- Logout revokes the refresh token; refresh rotates it.
- Public registration cannot assign admin role.
- `authenticate` verifies access token and attaches `req.user`.
- `authorize(...roles)` blocks disallowed roles with HTTP 403.
- Permission-based RBAC is demonstrated in `middlewares/permissions.js`.
- Ownership checks restrict patient and doctor data; doctors can prescribe only for their assigned appointments.
- Five failed logins lock an account for 15 minutes; login endpoint is rate-limited.
- Joi/Zod/express-validator requirement is met using express-validator.
- Central error handler handles 400, 401, 403, 404, 409 and 500 responses.
- Helmet, CORS, request-size limit and login rate limiting are enabled.
- Audit logs record important actions.
- User listing supports pagination, search and role filter.
- Forgot/reset password uses an expiring, hashed reset token.

## 6. Postman demo order
1. Health check.
2. Login with seeded admin; save `accessToken` and `refreshToken`.
3. Admin creates departments and registers a patient (and role changes a registered user to doctor/receptionist).
4. Register/login as patient and book an appointment with the doctor's MongoDB ID.
5. Login as doctor and list appointments; create prescription for the assigned appointment.
6. Login as patient and verify only their own appointment/prescription is visible.
7. Login as admin and demonstrate user listing, role change, block/unblock and audit logs.
8. Demonstrate refresh, logout, invalid refresh, wrong-role 403, and login lockout.

## Important production note
For this one-day assignment, the forgot-password endpoint returns the reset token to make Postman testing possible. In a real deployment, send the token through a verified email provider and never return it in the API response. Use HTTPS, rotate secrets, configure a strict CORS origin, and add automated tests before production.
