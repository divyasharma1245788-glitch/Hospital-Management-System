// Bonus: permission-based RBAC. Roles receive permissions; routes check permissions, not role names.
const map = {
  admin: ['user:read','user:role','user:block','department:manage','appointment:read:any','prescription:read:any','prescription:create:own'],
  doctor: ['appointment:read:own','prescription:create:own','prescription:read:own'],
  receptionist: ['patient:create','appointment:create','appointment:manage'],
  patient: ['appointment:create:own','appointment:read:own','prescription:read:own']
};
exports.hasPermission = permission => (req,res,next) => (map[req.user.role] || []).includes(permission) ? next() : res.status(403).json({message:'Forbidden: missing permission'});
